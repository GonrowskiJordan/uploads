/*
Example of example/demo project for LPC1768 in Keil uVision 5.
Code snippet from LPC1768 GPIO Tutorial
		@ http://www.ocfreaks.com/lpc1768-gpio-programming-tutorial/
(c) Umang Gajera 2017.

More embedded tutorial @ http://www.ocfreaks.com/cat/embedded/

*/
#include <lpc17xx.h>

void delay(void);

int main(void)
{
	LPC_GPIO0->FIODIR = 0xFFFFFFFF; // Configure all pins on Port 0 as Output
	
	while(1)
	{
		LPC_GPIO0->FIOSET = 0xFFFFFFFF; // Turn on LEDs
		delay();
		LPC_GPIO0->FIOCLR = 0xFFFFFFFF; // Turn them off
		delay();
	}
	// return 0; // normally this wont execute
}	

void delay(void) //Hardcoded delay function
{
	unsigned int count,i=0;
	for(count=0; count < 3000000/*000*/; count++) // You can edit this as per your needs
	{
		i++; // something needs to be here else compiler will remove the for loop!
	}
}
